# calculadora

Calculadora simples em Flutter.

## Getting Started

Esse projeto implementa uma calculadora simples para a compreensão de Flutter.
